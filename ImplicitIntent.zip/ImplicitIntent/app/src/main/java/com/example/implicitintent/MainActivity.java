package com.example.implicitintent;

import static com.example.implicitintent.R.*;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText emailText;
    private EditText EditText;
    private EditText tvmessage;
    private Button btnsendEmail;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Fixed the resource reference

        emailText = findViewById(R.id.emailText);  // Fixed the resource reference
        EditText = findViewById(R.id.EditText);  // Fixed the resource reference
        tvmessage = findViewById(R.id.tvmessage);  // Fixed the resource reference
        btnsendEmail = findViewById(R.id.btnsendEmail);  // Fixed the resource reference

        btnsendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Mengambil teks dari EditText
                String email = emailText.getText().toString();
                String subject = EditText.getText().toString();
                String message = tvmessage.getText().toString();

                // Cek apakah input sudah lengkap
                if (!email.isEmpty() && !subject.isEmpty() && !message.isEmpty()) {
                    // Coba mengirim email menggunakan ACTION_SENDTO dengan URI mailto:
                    Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                    emailIntent.setData(Uri.parse("mailto:" + email));
                    emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                    emailIntent.putExtra(Intent.EXTRA_TEXT, message);

                    // Jika tidak ada aplikasi yang mendukung, coba gunakan ACTION_SEND dengan filter email
                    if (emailIntent.resolveActivity(getPackageManager()) != null) {
                        startActivity(emailIntent);
                    } else {
                        // Jika ACTION_SENDTO tidak bekerja, coba dengan ACTION_SEND dan tipe rfc822
                        Intent fallbackIntent = new Intent(Intent.ACTION_SEND);
                        fallbackIntent.setType("message/rfc822");
                        fallbackIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                        fallbackIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                        fallbackIntent.putExtra(Intent.EXTRA_TEXT, message);

                        // Menampilkan aplikasi email melalui chooser
                        try {
                            startActivity(Intent.createChooser(fallbackIntent, "Choose an email client"));
                        } catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(MainActivity.this, "No email client installed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    // Menampilkan pesan jika ada input yang kosong
                    Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
